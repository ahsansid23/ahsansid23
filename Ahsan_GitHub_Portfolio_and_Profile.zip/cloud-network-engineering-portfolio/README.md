# Cloud Network Engineering Portfolio

Starter portfolio for practical cloud networking, automation, and network operations demos. The projects are portfolio/demo work, not claims of production deployment or employer work.

## Projects
1. **OpenShift application networking and isolation:** Route, service, deployment, and scoped Kubernetes NetworkPolicy.
2. **AWS VPC reference architecture (Terraform):** segmented public/private subnets and routing, suitable for plan review.
3. **Network configuration backup (Ansible):** lab playbook example; use Ansible Vault or a secret manager for credentials.
4. **Network health report (Python):** offline availability and packet-loss summary from synthetic CSV input.

Before publishing, run and document each project, replace examples with your own verified work, and remove secrets, customer data, internal IPs, and diagrams. Add your actual GitHub URL to your CV only after publishing and reviewing the repository.
