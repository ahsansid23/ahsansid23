# AWS VPC reference architecture

Terraform starter for a VPC with two public and two private subnets across availability zones. NAT is omitted to avoid surprise cost. Run `terraform init`, `terraform fmt -check`, `terraform validate`, then `terraform plan -var='admin_cidr=YOUR_PUBLIC_IP/32'`. No deployment occurs unless you explicitly run `apply`; review the plan and costs first.
