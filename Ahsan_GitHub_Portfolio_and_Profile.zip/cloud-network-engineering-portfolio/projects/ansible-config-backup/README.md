# Network configuration backup

Lab playbook example for collecting configurations and writing local backups. The included inventory uses documentation-only IP space. Review the platform module for your lab devices. Keep credentials in Ansible Vault or an external secret manager.
